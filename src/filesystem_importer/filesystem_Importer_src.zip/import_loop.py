
# =============================================================================
#
# Filesystem Importer
#
# Copyright (c) 2026 Geoff <dev.photomanager@gmail.com>
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
#
# =============================================================================

"""Control the filesystem photo-import loop."""

from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from datetime import datetime, timezone
from filesystem_importer.photo_staging import (
    PhotoStagingResult,
    StagingFatalError,
    stage_and_test_photo,
)
from filesystem_importer.app_logging import get_logger
from filesystem_importer.checkpoint_writer import (
    write_recovery_checkpoint,
)

logger = get_logger(__name__)



@dataclass(frozen=True)
class ImportProgress:
    """Progress counts for one import run."""

    total: int
    processed: int
    successful: int
    failed: int
    remaining: int



def initialise_progress(checkpoint: dict[str, Any]) -> ImportProgress:
    """Calculate progress from the saved checkpoint records."""
    try:
        total = checkpoint["filesystem_importer"]["source_manifest"][
            "candidate_count"
        ]
        photos = checkpoint["photos"]
    except (KeyError, TypeError) as exc:
        raise ValueError("Checkpoint is missing required progress data.") from exc

    if isinstance(total, bool) or not isinstance(total, int) or total < 0:
        raise ValueError("Checkpoint candidate_count must be a non-negative integer.")

    if not isinstance(photos, list):
        raise ValueError("Checkpoint photos must be a list.")

    processed = len(photos)

    if processed > total:
        raise ValueError("Checkpoint has more photo records than source candidates.")

    successful = 0
    failed = 0

    for index, photo in enumerate(photos):
        if not isinstance(photo, Mapping):
            raise ValueError(f"Photo record {index} must be an object.")

        downloaded = photo.get("downloaded")

        if not isinstance(downloaded, bool):
            raise ValueError(
                f"Photo record {index} must have a Boolean downloaded value."
            )

        if downloaded:
            successful += 1
        else:
            failed += 1

    return ImportProgress(
        total=total,
        processed=processed,
        successful=successful,
        failed=failed,
        remaining=total - processed,
    )


def stage_candidate(
    source_path: Path,
    photos_directory: Path,
) -> PhotoStagingResult:
    """Stage a candidate and test EXIF capability.

    Return the complete staging result, including the staged filename
    on success or the failure reason on failure.

    Fatal staging errors propagate to stop processing.
    """
    result = stage_and_test_photo(source_path, photos_directory)

    if not result.success:
        logger.info(
            "Candidate failed the staging/EXIF test: %s (%s)",
            source_path,
            result.reason,
        )
    else:
        logger.info(
            "Candidate passed the staging/EXIF test: %s -> %s",
            source_path,
            result.staged_filename,
        )

    return result


def build_failed_photo_record(
    source_path: Path,
    event_name: str,
) -> dict[str, Any]:
    """Build a photo record for a candidate that failed staging."""
    return build_photo_record(
        source_path=source_path,
        downloaded=False,
        file="",
        event=event_name,
    )

def process_candidate(
    source_path: Path,
    photos_directory: Path,
    event_name: str,
) -> dict[str, Any] | None:
    """Process one candidate."""

    result = stage_candidate(source_path, photos_directory)

    if not result.success:
        return build_failed_photo_record(source_path, event_name)

    logger.info(
        "Candidate staged successfully; metadata resolution is pending: %s",
        source_path,
    )
    return None

def update_progress_display(progress: ImportProgress) -> None:
    """Update the GUI with the latest progress."""
    raise NotImplementedError

def save_recovery_checkpoint(
    checkpoint: dict[str, Any],
    checkpoint_path: Path,
) -> None:
    """Save the current checkpoint for recovery."""
    write_recovery_checkpoint(
        checkpoint_path=checkpoint_path,
        checkpoint=checkpoint,
    )



def run_import_loop(
    checkpoint: dict[str, Any],
    candidate_paths: list[Path],
    photos_directory: Path,
    checkpoint_path: Path,
) -> ImportProgress:
    """Process failed candidates until a successful candidate needs metadata.

    Failed candidates receive complete records and are appended to the
    checkpoint. Successful candidates stop processing until metadata
    resolution has been implemented.
    """
    progress = initialise_progress(checkpoint)
    update_progress_display(progress)

    if len(candidate_paths) != progress.total:
        raise ValueError(
            "Candidate path count does not match the checkpoint manifest."
        )

    event_name = checkpoint["workspace"]["event"]

    for source_path in candidate_paths[progress.processed:]:
        record = process_candidate(
            source_path=source_path,
            photos_directory=photos_directory,
            event_name=event_name,
        )

        if record is None:
            raise NotImplementedError(
                "Metadata resolution is not implemented; "
                "the successful candidate has been staged but not recorded."
            )

        checkpoint["photos"].append(record)
        progress = initialise_progress(checkpoint)
        update_progress_display(progress)

        logger.info(
            "Failed candidate recorded: %s (%d of %d processed)",
            source_path,
            progress.processed,
            progress.total,
        )

        save_recovery_checkpoint(
            checkpoint=checkpoint,
            checkpoint_path=checkpoint_path,
        )

    return progress

def build_photo_record(
    source_path: Path,
    *,
    downloaded: bool,
    file: str,
    event: str,
    moment_id: str = "",
    lat: float | None = None,
    lng: float | None = None,
    retry_count: int = 0,
    status: str = "pending",
    exif_written: bool = False,
    location_key: str | None = None,
    geo_location: str | None = None,
    year: str = "",
    location: str = "",
    info: str = "",
) -> dict[str, Any]:
    """Build a photo record using the standard Project JSON structure."""
    last_updated = (
        datetime.now(timezone.utc)
        .isoformat(timespec="milliseconds")
        .replace("+00:00", "Z")
    )

    return {
        "guid": str(Path(source_path).resolve()),
        "moment_id": moment_id,
        "lat": lat,
        "lng": lng,
        "file": file,
        "downloaded": downloaded,
        "retry_count": retry_count,
        "status": status,
        "exif_written": exif_written,
        "last_updated": last_updated,
        "location_key": location_key,
        "geo_location": geo_location,
        "event": event,
        "year": year,
        "location": location,
        "info": info,
    }
